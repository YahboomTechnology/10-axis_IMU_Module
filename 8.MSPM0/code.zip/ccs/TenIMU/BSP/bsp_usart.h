#ifndef __BSP_USART_H_
#define __BSP_USART_H_

#include "ti_msp_dl_config.h"
#include "bsp_delay.h"
#include "imu_use.h"

void uart0_send_char(char ch);
void uart0_send_string(char* str);

#endif


#ifndef __K210_USE_H_
#define __K210_USE_H_




#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "stdint.h"
#include "ti_msp_dl_config.h"
#include "bsp_usart.h"

void DueData(uint8_t inputdata);
void GetDataDeal(void);


extern int acc[3],gyro[3],angle[3];
extern uint8_t g_newflag;

#endif



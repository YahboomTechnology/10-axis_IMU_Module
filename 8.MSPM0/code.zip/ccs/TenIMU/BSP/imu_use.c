#include "imu_use.h"


uint8_t RxBuff[11] = {'\0'};
uint8_t RxBuffnew[11] = {'\0'};

uint32_t CheckSum = 0;  // Sum check bit
uint32_t CheckSumnew = 0;


uint8_t start = 0; //֡ͷ��ʼ�ı�־ The frame header starts
uint8_t data_length = 0; //����Э����ĵ�����Ϊ11 eg:55 51 31 FF 53 02 CD 07 12 0A 1B According to the agreement, the document length is 11 eg:55 51 31 FF 53 02 CD 07 12 0A 1B

uint8_t g_newflag = 0;

int acc[3],gyro[3],angle[3];


void DueData(uint8_t inputdata)  
{
    if (inputdata == 0x55 && start == 0)
		{
				start = 1;
        data_length = 10;			
				RxBuff[0] = 0x55;
				CheckSum = 0x55;
				return;
		}
		if(start == 1)
		{
			if(inputdata == 0x53) //��Ϊ����̫�ߣ�����ȫ����ȡ��Ϣ��������ֻ��ȡ��̬�Ƕ� Because the rate is too high, it is not possible to obtain all the information. This routine only obtains the attitude angle
			{
				start = 2 ;
			}
			else
			{
				//��ֹ�������ݳ���0x53����Ч���� Prevent other data from showing valid data of 0x53
				memset(RxBuff,0,11);
				start = 0;
			}
		}
        
		
    if (start == 2)
		{
			  CheckSum += inputdata; //У������� ���У��λ���� The checksum calculation will add the check digit
        RxBuff[11-data_length] = inputdata; //�������� Save data
        data_length = data_length - 1; //���ȼ�һ Length minus one
			
        if (data_length == 0) //���յ����������� Received complete data
				{
					  CheckSum = (CheckSum-inputdata) & 0xff; 
            start = 0; //��0 Clear
						memcpy(RxBuffnew,RxBuff,11);
					
						CheckSumnew = CheckSum; 
//						g_newflag = 1;
            memset(RxBuff,0,11);
						
						GetDataDeal();
				}	
		}
}


void GetDataDeal(void)
{
    if(RxBuffnew[10] != CheckSumnew) //У���벻��ȷ The check code is incorrect
		{
			 CheckSumnew = 0;
				memset(RxBuffnew,0,11);
			 return;
		}
        
//    if(RxBuffnew[1] == 0x51) //���ٶ���� Acceleration output
//		{
//			
//				acc[0] = (RxBuffnew[3] << 8 | RxBuffnew[2])/ 32768.0 * 16.0 ; 
//				acc[1] = (RxBuffnew[5] << 8 | RxBuffnew[4])/ 32768.0 * 16.0 ;
//				acc[2] = (RxBuffnew[7] << 8 | RxBuffnew[6])/ 32768.0 * 16.0 ;
////				if (acc[0] >= 16.0)
////				{
////					acc[0] -= 2 * 16.0;
////				}
////						
////				if (acc[1] >= 16.0)
////				{
////					acc[1] -= 2 * 16.0;
////				}
////						
////				if (acc[2] >= 16.0)
////				{
////						acc[2] -= 2 * 16.0;
////				}
//					
//           
//		}
//       

//    else if(RxBuffnew[1] == 0x52) //���ٶ���� Angular velocity output
//		{
//				gyro[0] = (RxBuffnew[3] << 8 | RxBuffnew[2]) / 32768.0 * 2000.0;
//				gyro[1] = (RxBuffnew[5] << 8 | RxBuffnew[4]) / 32768.0 * 2000.0;
//				gyro[2] = (RxBuffnew[7] << 8 | RxBuffnew[6]) / 32768.0 * 2000.0;
////				if (gyro[0] >= 2000.0)
////				{
////					gyro[0] -= 2 * 2000.0;
////				}
////						
////				if (gyro[1] >= 2000.0)
////				{
////					gyro[1] -= 2 * 2000.0;
////				}
////						
////				if (gyro[2] >= 2000.0)
////				{
////						gyro[2] -= 2 * 2000.0;
////				}
//				
//		}
//       

//    else 
			if(RxBuffnew[1] == 0x53) //��̬�Ƕ���� Attitude angle output
		{
				angle[0] = (RxBuffnew[3] << 8 | RxBuffnew[2]) / 32768.0 * 180.0;
				angle[1] = (RxBuffnew[5] << 8 | RxBuffnew[4]) / 32768.0 * 180.0;
				angle[2] = (RxBuffnew[7] << 8 | RxBuffnew[6]) / 32768.0 * 180.0;
			
			printf("angle:x:%d y:%d z:%d \r\n" ,(int)angle[0],(int)angle[1],(int)angle[2]);
//				if (gyro[0] >= 180.0)
//				{
//					gyro[0] -= 2 * 180.0;
//				}
//						
//				if (gyro[1] >= 180.0)
//				{
//					gyro[1] -= 2 * 180.0;
//				}
//						
//				if (gyro[2] >= 180.0)
//				{
//						gyro[2] -= 2 * 180.0;
//				}
						
		}
		
		CheckSumnew = 0;
		memset(RxBuffnew,0,11);
		
		
}
   
   

    